package xml;

public class FacilityMgr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
